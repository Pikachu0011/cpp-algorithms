//#include<bits/stdc++.h>
//#include <string.h>
//using namespace std;
//
//#define MaxSize 100
//typedef char ElemType;
//typedef struct {
//	ElemType data[MaxSize];
//	int top;
//} SqStack;
//void InitStack(SqStack& st)		//stΪ�����Ͳ���
//{
//	st.top = -1;
//}
//void DestroyStack(SqStack &st)
//{
//	st.top = -1;
//}
//
//int Push(SqStack & st, ElemType x)
//{
//	if (st.top == MaxSize - 1)	//ջ��
//		return 0;
//	else
//	{	
//		st.top++;
//		st.data[st.top] = x;
//		return 1;
//	}
//}
//
//int Pop(SqStack& st, ElemType& x)	//xΪ�����Ͳ���
//{
//	if (st.top == -1)					//ջ��
//		return 0;
//	else
//	{
//		x = st.data[st.top];
//		st.top--;
//		return 1;
//	}
//}
//
//int GetTop(SqStack &st, ElemType& x)	//xΪ�����Ͳ���
//{
//	if (st.top == -1)					//ջ��
//		return 0;
//	else
//	{	
//		x = st.data[st.top];
//		return 1;
//	}
//}
//bool Stackempty(SqStack& st) {
//	return (st.top == -1);
//}
//int StackEmpty(SqStack st)
//{
//	if (st.top == -1) return 1;
//	else return 0;
//}
//int Palindrome(char str[], int n)
//{
//	SqStack st;					//����һ��˳��ջst
//	InitStack(st);				//ջ��ʼ��
//	int i;
//	char ch;
//	for (int i = 0; i < n; i++) {
//		Push(st, str[i]);
//	}
//	for (int i = 0; i < n; i++) {
//		Pop(st, ch);
//		if (ch != str[i])return 0;
//	}
//	return 1;					//������Ӧ�ַ�����ͬʱ����1
//}
//int Match(char exp[], int n)				//exp��ű���ʽ
//{
//	SqStack st;							//����һ��˳��ջst
//	InitStack(st);						//ջ��ʼ��
//	int flag = 1, i = 0;
//	char ch;
//	while (i < n && flag == 1)				//��������ʽexp
//	{
//		switch (exp[i])
//		{
//		case '(':
//			Push(st, exp[i]);
//			break;
//		case '[':
//			Push(st, exp[i]);
//			break;
//		case '{':
//			Push(st, exp[i]);
//			break;
//		case ')':
//			if (!Pop(st, ch) || ch != '(')flag = 0;
//			break;
//		case ']':
//			if (!Pop(st, ch) || ch != '[')flag = 0;
//			break;
//		case '}':
//			if (!Pop(st, ch) || ch != '{')flag = 0;
//			break;
//		default :
//			break;
//		}
//		i++;
//	}
//	if (StackEmpty(st) && flag == 1)		//ջ���ҷ���ƥ���򷵻�1
//	{
//		DestroyStack(st);				//����ջst
//		return 1;
//	}
//	else
//	{
//		DestroyStack(st);				//����ջst
//		return 0;						//���򷵻�0
//	}
//}
//void display(char exp[])
//{
//	int n = strlen(exp);
//	if (Match(exp, n))
//		printf("  %s��ƥ��ı���ʽ\n", exp);
//	else
//		printf("  %s����ƥ��ı���ʽ\n", exp);
//}
//
//void main() {
//	cout << "������ 241400003617 ʵ����\n";
//	char s1[] = "([()])";
//	char s2[] = "[{()]}";
//	char s3[] = "{([])}";
//	char s4[] = "([(])}";
//	display(s1);
//	display(s2);
//	display(s3);
//	display(s4);
//}
