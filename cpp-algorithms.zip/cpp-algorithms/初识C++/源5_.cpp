//#include"iostream"
//using namespace std;
//int main() {
//	int age = 18;
//	string name = "С��";
//	char gender = 'm';
//	cout << name << "����" << age <<endl<< "�Ա�" << gender << endl;
//
//	return 0;
//}
