#include<bits/stdc++.h>
using namespace std;
int main() {
	int n, m;
	cin

	return 0;
}