//#include<iostream>
//#include<algorithm>
//using namespace std;
//struct Process {//����
//    int pid;//���̱�ʾ 
//    int daotime;//����ʱ�� 
//    int servetime;//����ʱ�� 
//    int begintime;//��ʼʱ�� 
//    int finishtime;//����ʱ�� 
//    int turntime;// ��תʱ�� 
//    float quantime; //��Ȩ��תʱ�� 
//};
//bool cmp(Process a, Process b) {
//    return a.daotime < b.daotime;
//}
//
//int main() {
//    int n;
//    cout << "�����������";
//    cin >> n;
//
//    Process p[100];
//
//    for (int i = 0; i < n; i++) {
//        p[i].pid = i + 1;
//        cin >> p[i].daotime >> p[i].servetime;
//    }
//
//    sort(p, p + n, cmp);
//
//    int lastFinish = 0;
//    for (int i = 0; i < n; i++) {
//
//        if (lastFinish <= p[i].daotime)
//            p[i].begintime = p[i].daotime;
//        else
//            p[i].begintime = lastFinish;
//
//        p[i].finishtime = p[i].begintime + p[i].servetime;
//
//        p[i].turntime = p[i].finishtime - p[i].daotime;
//
//        p[i].quantime = 1.0 * p[i].turntime / p[i].servetime;
//
//        lastFinish = p[i].finishtime;
//    }
//
//    printf("PID\t����\t����\t��ʼ\t����\t��ת\t��Ȩ��ת\n");
//    for (int i = 0; i < n; i++) {
//        printf("%d\t%d\t%d\t%d\t%d\t%d\t%.2f\n",
//            p[i].pid,
//            p[i].daotime,
//            p[i].servetime,
//            p[i].begintime,
//            p[i].finishtime,
//            p[i].turntime,
//            p[i].quantime);
//    }
//
//    return 0;
//}