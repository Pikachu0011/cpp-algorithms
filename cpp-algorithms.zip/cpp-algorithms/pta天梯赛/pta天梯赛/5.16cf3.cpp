//#include <bits/stdc++.h>
//using namespace std;
//using ull = unsigned long long;
//
//string ull_to_str(ull x) {
//    if (x == 0) return "0";
//    string s;
//    while (x > 0) {
//        s.push_back('0' + (x % 10));
//        x /= 10;
//    }
//    reverse(s.begin(), s.end());
//    return s;
//}
//
//ull str_to_ull(const string& s) {
//    ull x = 0;
//    for (char c : s) x = x * 10 + (c - '0');
//    return x;
//}
//
//// ���쳤��Ϊ L ����С������λ����Ϊ0���� L>1��
//string build_min_len(const int D[2], int L) {
//    if (L == 1) return string(1, char('0' + D[0])); // D[0] �ǽ�С��
//    int first = -1;
//    if (D[0] != 0) first = D[0];
//    else if (D[1] != 0) first = D[1];
//    if (first == -1) return string(); // �޷����죨ֻ��0�� L>1��
//    string t;
//    t.push_back(char('0' + first));
//    char mn = char('0' + D[0]);
//    for (int i = 1; i < L; i++) t.push_back(mn);
//    return t;
//}
//
//// ���쳤��Ϊ L �����������λ����Ϊ0���� L>1��
//string build_max_len(const int D[2], int L) {
//    if (L == 1) return string(1, char('0' + D[1])); // D[1] �ǽϴ��
//    int first = -1;
//    if (D[1] != 0) first = D[1];
//    else if (D[0] != 0) first = D[0];
//    if (first == -1) return string();
//    string t;
//    t.push_back(char('0' + first));
//    char mx = char('0' + D[1]);
//    for (int i = 1; i < L; i++) t.push_back(mx);
//    return t;
//}
//
//// �ȳ�������С�� >= s�������ڷ����ַ��������򷵻ؿգ�
//string ceil_equal(const int D[2], const string& s) {
//    int m = s.size();
//    string t(m, '?');
//    for (int pos = 0; pos < m; ++pos) {
//        int need = s[pos] - '0';
//        int pick = -1;
//        // ��������������С�� >= need������λ����Լ��
//        for (int k = 0; k < 2; k++) {
//            int d = D[k];
//            if (pos == 0 && m > 1 && d == 0) continue;
//            if (d >= need) {
//                pick = d;
//                break; // D sorted ascending
//            }
//        }
//        if (pick != -1) {
//            t[pos] = char('0' + pick);
//            if (pick > need) {
//                // �������С��
//                char mn = char('0' + D[0]);
//                for (int j = pos + 1; j < m; j++) t[j] = mn;
//                return t;
//            }
//            else {
//                // equal, ����
//                continue;
//            }
//        }
//        else {
//            // ��ǰλ��û�� >= need�����ݵ�ǰ���ҿ��������λ��
//            int j = pos - 1;
//            bool done = false;
//            while (j >= 0) {
//                int cur = t[j] - '0';
//                // �ҵ��� cur �����С����
//                int next = -1;
//                for (int k = 0; k < 2; k++) {
//                    if (D[k] > cur) {
//                        if (j == 0 && m > 1 && D[k] == 0) continue;
//                        next = D[k];
//                        break;
//                    }
//                }
//                if (next != -1) {
//                    t[j] = char('0' + next);
//                    // ������Ϊ��С
//                    char mn = char('0' + D[0]);
//                    for (int z = j + 1; z < m; ++z) t[z] = mn;
//                    return t;
//                }
//                else j--;
//            }
//            return string();
//        }
//    }
//    // ȫ��ƥ�䣬s ��������λ���� D ��
//    return t;
//}
//
//// �ȳ��������� <= s�������ڷ����ַ��������򷵻ؿգ�
//string floor_equal(const int D[2], const string& s) {
//    int m = s.size();
//    string t(m, '?');
//    for (int pos = 0; pos < m; ++pos) {
//        int need = s[pos] - '0';
//        int pick = -1;
//        // ���������������� <= need������λ����Լ��
//        for (int k = 1; k >= 0; k--) {
//            int d = D[k];
//            if (pos == 0 && m > 1 && d == 0) continue;
//            if (d <= need) {
//                pick = d;
//                break;
//            }
//        }
//        if (pick != -1) {
//            t[pos] = char('0' + pick);
//            if (pick < need) {
//                // ��������
//                char mx = char('0' + D[1]);
//                for (int j = pos + 1; j < m; j++) t[j] = mx;
//                return t;
//            }
//            else {
//                continue;
//            }
//        }
//        else {
//            // �� <= need������ǰ���ҿ��Լ�С��λ��
//            int j = pos - 1;
//            bool done = false;
//            while (j >= 0) {
//                int cur = t[j] - '0';
//                int prev = -1;
//                for (int k = 0; k < 2; k++) {
//                    if (D[k] < cur) {
//                        prev = D[k]; // since D[0] < D[1], scanning low->high finds smaller; but we need largest < cur, so check both
//                    }
//                }
//                // better do explicit:
//                int choose = -1;
//                if (D[1] < cur) {
//                    if (j == 0 && m > 1 && D[1] == 0) {
//                        // try D[0] maybe also zero
//                        if (D[0] < cur && !(j == 0 && m > 1 && D[0] == 0)) choose = D[0];
//                    }
//                    else choose = D[1];
//                }
//                else if (D[0] < cur) {
//                    if (!(j == 0 && m > 1 && D[0] == 0)) choose = D[0];
//                }
//                if (choose != -1) {
//                    t[j] = char('0' + choose);
//                    char mx = char('0' + D[1]);
//                    for (int z = j + 1; z < m; ++z) t[z] = mx;
//                    return t;
//                }
//                else j--;
//            }
//            return string();
//        }
//    }
//    return t;
//}
//
//int main() {
//    ios::sync_with_stdio(false);
//    cin.tie(nullptr);
//    int T;
//    if (!(cin >> T)) return 0;
//    while (T--) {
//        ull a;
//        int n;
//        cin >> a >> n;
//        int Darr[2];
//        cin >> Darr[0] >> Darr[1];
//        if (Darr[0] > Darr[1]) swap(Darr[0], Darr[1]);
//        string s = to_string(a);
//        int m = (int)s.size();
//        ull best = (ull)(-1); // ULLONG_MAX
//
//        auto consider = [&](const string& t) {
//            if (t.empty()) return;
//            if (t.size() > 1 && t[0] == '0') return;
//            ull val = str_to_ull(t);
//            ull diff = (val >= a) ? (val - a) : (a - val);
//            if (diff < best) best = diff;
//            };
//
//        for (int L = 1; L <= m + 1; ++L) {
//            if (L < m) {
//                string t = build_max_len(Darr, L);
//                consider(t);
//            }
//            else if (L > m) {
//                string t = build_min_len(Darr, L);
//                consider(t);
//            }
//            else {
//                string c1 = ceil_equal(Darr, s);
//                consider(c1);
//                string c2 = floor_equal(Darr, s);
//                consider(c2);
//            }
//        }
//        if (best == (ull)(-1)) best = 0;
//        cout << best << '\n';
//    }
//    return 0;
//}
