//#include<bits/stdc++.h>
//using namespace std;
//int main() {
//	int n;
//	cin >> n;
//
//	string name[10000];
//	int num[10000];
//	int sum = 0;
//	for (int i = 0; i < n; i++) {
//		cin >> name[i] >> num[i];
//		sum += num[i];
//	}
//	int ave = sum / (2 * n);
//	int minn = 10000;//������abs(num[0] - ave)��Ӧ�ó�ʼ��һ���ϴ��ֵ��
//	string win;
//	for (int i = 0; i < n; i++) {
//		if (abs(num[i] - ave) < minn) {
//			minn = abs(num[i] - ave);
//			win = name[i];
//		}
//	}
//	cout << ave << " " << win << endl;
//
//
//
//
//	return 0;
//}