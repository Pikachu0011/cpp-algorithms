//#include<bits/stdc++.h>
//using namespace std;
//int main() {
//	string s;
//	getchar();
//	getline(cin, s);
//	string min;
//	//getchar();
//	getline(cin, min);
//	if (s.find(min) != -1) {
//		cout << "���дʵ���ʼλ��Ϊ" << s.find(min) + 1 << endl;
//	}
//	else {
//		cout << "û�����д�" << endl;
//	}
//	return 0;
//}