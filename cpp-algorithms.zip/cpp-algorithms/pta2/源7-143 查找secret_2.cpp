//#include<bits/stdc++.h>
//using namespace std;
//int main() {
//	string s, str;
//	int cnt = 0;
//	getline(cin, s);
//	stringstream ss(s);//��s���浽ss����
//	vector<int> ve;
//	bool flag = 0;
//	while (ss >> str) {//����ssÿ��Ԫ�ظ�ֵ��str
//		cnt++;
//		if (str == "secret") {
//			flag = 1;
//			ve.push_back(cnt);
//		}
//
//
//	}
//	if (flag) {
//		for (auto i : ve) {
//			cout << "\"secret\" is pos " << i << endl;
//		}
//	}
//	else {
//		cout << "No \"secret\"" << endl;
//	}
//
//	return 0;
//}