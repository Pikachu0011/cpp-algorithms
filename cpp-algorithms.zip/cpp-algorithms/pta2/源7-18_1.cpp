//#include<bits/stdc++.h>
//using namespace std;
//
//const int N = 1e3 + 5;
//const int M = 1e3 + 5;
//char ss[N][M];
//bool vis[N][M];
//int n, m, k; // ���� ���� ������ִ�в����Ĵ���
//int x0, sY, d0; // ��ʼ�� �� ����
//
//// �������飬�ֱ��Ӧ�����ϡ�������
//int dx[4] = { 0, 1, 0, -1 };
//int dy[4] = { 1, 0, -1, 0 };
//
//bool check(int x, int y) {
//    return x >= 1 && x <= n && y >= 1 && y <= m;
//}
//
//int main() {
//    int T; // ����
//    cin >> T;
//
//    while (T--) {
//        int ans = 1;
//        cin >> n >> m >> k;
//        cin >> x0 >> sY >> d0;
//
//        // ��ʼ�� vis ����
//        memset(vis, 0, sizeof(vis));
//
//        for (int i = 1; i <= n; ++i) {
//            for(int j=1;j<=m;j++)
//                cin >> ss[i][j];
//            
//        }
//
//        int xx = x0;
//        int yy = sY;
//        vis[xx][yy] = 1;
//
//        while (k--) {
//            int nx = xx + dx[d0];
//            int ny = yy + dy[d0];
//
//            if (check(nx, ny) && ss[nx][ny] == '.' ) {
//                
//                xx = nx;
//                yy = ny;
//                if (vis[nx][ny] == 0) {
//                    ans++;
//                    vis[nx][ny] = 1;
//                }
//                
//            }
//            else {
//                d0 = (d0 + 1) % 4; // ˳ʱ����ת 90 ��
//            }
//        }
//
//        cout << ans << endl;
//    }
//
//    return 0;
//}