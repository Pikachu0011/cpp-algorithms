//#include <stdio.h>
//#define MAX_N 105
//#define MAX_M 25
//
//int frames[MAX_M];     // ������ҳ���
//int R[MAX_M];          // ����λ 0/1
//int M[MAX_M];          // �޸�λ 0/1
//int pages[MAX_N];      // ҳ���������
//int modify[MAX_N];     // ÿ��ҳ���Ƿ��޸�
//int frame_cnt = 0;
//int ptr = 0;           // Clockѭ��ָ��
//
//// �ж�ҳ���Ƿ��������飬�����±꣬����-1
//int findPage(int page)
//{
//    for (int i = 0; i < frame_cnt; i++)
//    {
//        if (frames[i] == page)
//            return i;
//    }
//    return -1;
//}
//
//// ��һ�֣��� R=0 && M=0
//int findType1()
//{
//    for (int i = 0; i < frame_cnt; i++)
//    {
//        int pos = (ptr + i) % frame_cnt;
//        if (R[pos] == 0 && M[pos] == 0)
//        {
//            ptr = (pos + 1) % frame_cnt;
//            return pos;
//        }
//    }
//    return -1;
//}
//
//// �ڶ��֣��� R=0 && M=1����;R��0
//int findType2()
//{
//    for (int i = 0; i < frame_cnt; i++)
//    {
//        int pos = (ptr + i) % frame_cnt;
//        if (R[pos] == 0 && M[pos] == 1)
//        {
//            ptr = (pos + 1) % frame_cnt;
//            return pos;
//        }
//        R[pos] = 0;
//    }
//    return -1;
//}
//
//// �����֣�����ɨ���� Type1
//int findType1Again()
//{
//    for (int i = 0; i < frame_cnt; i++)
//    {
//        int pos = (ptr + i) % frame_cnt;
//        if (R[pos] == 0 && M[pos] == 0)
//        {
//            ptr = (pos + 1) % frame_cnt;
//            return pos;
//        }
//    }
//    return -1;
//}
//
//// �����֣������ Type2
//int findType2Again()
//{
//    for (int i = 0; i < frame_cnt; i++)
//    {
//        int pos = (ptr + i) % frame_cnt;
//        if (R[pos] == 0 && M[pos] == 1)
//        {
//            ptr = (pos + 1) % frame_cnt;
//            return pos;
//        }
//    }
//    return 0;
//}
//
//// �Ľ���Clock��ȡ��̭λ��
//int getReplacePos()
//{
//    int pos;
//    pos = findType1();
//    if (pos != -1) return pos;
//
//    pos = findType2();
//    if (pos != -1) return pos;
//
//    pos = findType1Again();
//    if (pos != -1) return pos;
//
//    return findType2Again();
//}
//
//int main()
//{
//    int n, m;
//    scanf("%d %d", &n, &m);
//    for (int i = 0; i < n; i++)
//        scanf("%d", &pages[i]);
//    for (int i = 0; i < n; i++)
//        scanf("%d", &modify[i]);
//
//    int miss = 0;
//    for (int i = 0; i < n; i++)
//    {
//        int page = pages[i];
//        int md = modify[i];
//        int pos = findPage(page);
//
//        // ҳ�����У�����λ��1
//        if (pos != -1)
//        {
//            R[pos] = 1;
//            continue;
//        }
//
//        // ȱҳ
//        miss++;
//        if (frame_cnt < m)
//        {
//            frames[frame_cnt] = page;
//            R[frame_cnt] = 1;
//            M[frame_cnt] = md;
//            frame_cnt++;
//        }
//        else
//        {
//            int rep = getReplacePos();
//            frames[rep] = page;
//            R[rep] = 1;
//            M[rep] = md;
//        }
//    }
//
//    int rate = (miss * 100) / n;
//    printf("%d %d\n", miss, rate);
//    return 0;
//}