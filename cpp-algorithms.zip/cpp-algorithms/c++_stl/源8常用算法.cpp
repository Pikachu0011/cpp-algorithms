//#include<bits/stdc++.h>
//using namespace std;
//int main() {
//	int a = 1, b = 2;
//	cout << a << " " << b << endl;
//	swap(a, b);//������
//	cout << a << " " << b << endl;
//	vector<int> arr{ 1,9,1,9,8,1,0 };
//	sort(arr.begin(), arr.end());//��С��������
//	for (int i = 0; i < arr.size(); i++) {
//		cout << arr[i] << endl;
//	}
//	sort(arr.begin(), arr.end(), greater<int>());//�Ӵ�С����
//	cout << endl;
//
//
//	for (int i = 0; i < arr.size(); i++) {
//		cout << arr[i] << endl;
//	}
//	cout << endl;
//	
//	/*int pos = lower_bound(arr.begin(), arr.end(), 8) - arr.begin();
//	cout << pos << endl;
//	*/
//
//	return 0;
//}